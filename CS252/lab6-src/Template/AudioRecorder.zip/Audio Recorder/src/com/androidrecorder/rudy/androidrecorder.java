package com.androidrecorder.rudy;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import android.app.Activity;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class androidrecorder extends Activity {

	boolean recording = false;
	boolean playing = false;

	MediaRecorder recorder;
	MediaPlayer player;

	Button recordButton;
	Button playButton;

	Uri audioFilePath;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		// File to which audio should be recorded
		File outputFile = getFileStreamPath("output.amr");
		audioFilePath = Uri.parse(outputFile.getAbsolutePath());

		// Button to record to a file using microphone
		recordButton = (Button) findViewById(R.id.record);
		recordButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				// Safe check: Do not allow the button to be clicked if playing a sound
				if (playing)
					return;

				if (!recording) {
					// Start the recording
					recording = true;
					recordButton.setText("Stop Recording");
					playButton.setEnabled(false);

					recorder = new MediaRecorder();
					// This parameter set the input to be the microphone
					recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
					recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
					recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
					// We set the path of the file
					recorder.setOutputFile(audioFilePath.getPath());
					try {
						recorder.prepare();
						// Recording will start after next instruction
						recorder.start();
					} catch (IllegalStateException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				else {
					//Stop the recording and tidy up
					recorder.stop();
					recorder.release();

					recording = false;
					recordButton.setText("Record");
					playButton.setEnabled(true);
				}
			}
		});

		// Button to play the file sound
		playButton = (Button) findViewById(R.id.play);

		// By default, disable the button: A recording has to be made first
		playButton.setEnabled(false);

		playButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				// Safe check: Do not allow to play if recording a sound
				if (recording)
					return;

				if (!playing) {
					// Start playing the sound
					playing = true;
					playButton.setText("Stop Playing");
					recordButton.setEnabled(false);

					player = new MediaPlayer();
					try {
						File file = new File(audioFilePath.getPath());
						FileInputStream fis = new FileInputStream(file);
						player.setDataSource(fis.getFD());

						// We do not allow to loop/repeat the sound
						player.setLooping(false);

						player.prepare();
						player.start();
					} catch (IllegalArgumentException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IllegalStateException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

					// When we reach the end of the file
					player.setOnCompletionListener(new OnCompletionListener() { 
						@Override 
						public void onCompletion(MediaPlayer player) { 
							player.stop();

							playing = false;
							playButton.setText("Play");
							recordButton.setEnabled(true);
						}
					});
				}
				else {
					// Stop playing the sound
					player.stop();

					playing = false;
					playButton.setText("Play");
					recordButton.setEnabled(true);
				}
			}
		});
	}
}